package com.example.listview1;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class MyAdapter1 extends ArrayAdapter<String> {
    private String[] arr1;
    public MyAdapter1(@NonNull Context context, int resource, @NonNull String[] arr1) {
        super(context, resource, arr1);
        this.arr1=arr1;
    }
    @Nullable
    @Override
    public String getItem(int position) {
        return arr1[position];
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        convertView= LayoutInflater.from(getContext()).inflate(R.layout.mylayout,parent,false);
        TextView t1=convertView.findViewById(R.id.textView);
        t1.setText(getItem(position));
        return convertView;
    }
}
