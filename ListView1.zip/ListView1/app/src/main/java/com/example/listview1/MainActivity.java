package com.example.listview1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

@SuppressWarnings("ALL")
public class MainActivity extends AppCompatActivity {
    private ListView l1;
    String arr[]={"MCA","IT","Mechanical","Electrical"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        l1=findViewById(R.id.listview1);

        //ArrayAdapter ad=new ArrayAdapter(MainActivity.this, android.R.layout.simple_list_item_1, arr);
       // l1.setAdapter(ad);

        MyAdapter1 md1=new MyAdapter1(this,R.layout.mylayout,arr);
        l1.setAdapter(md1);
    }
}