package com.example.practical6;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private TextView t1;
    private EditText e1;
    private Button b1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        t1=findViewById(R.id.tv);
        e1=findViewById(R.id.editText);
        b1=findViewById(R.id.button);
        b1.setOnClickListener(new View.OnClickListener() { @Override
        public void onClick(View view) {
            String val=e1.getText().toString();
            SharedPreferences sp1=getSharedPreferences("myPref",MODE_PRIVATE);
            SharedPreferences.Editor ed=sp1.edit(); ed.putString("name",val);
            ed.apply(); t1.setText(val);

        }
        });

        SharedPreferences sp1=getSharedPreferences("myPref",MODE_PRIVATE); String editval=sp1.getString("name","No value"); t1.setText(editval);

    }
}