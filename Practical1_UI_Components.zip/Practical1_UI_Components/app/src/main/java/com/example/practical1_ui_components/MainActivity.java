package com.example.practical1_ui_components;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity {
    private Button button;
    private EditText editText;
    private TextView textView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        button = findViewById(R.id.button2);
        editText = findViewById(R.id.editTextTextPersonName2);
        textView = findViewById(R.id.textView3);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Calendar c = Calendar.getInstance();
                int timeOfDay = c.get(Calendar.HOUR_OF_DAY);
                if(timeOfDay >= 0 && timeOfDay < 12){ Toast.makeText(MainActivity.this, "",
                        Toast.LENGTH_SHORT).show();
                    Toast.makeText(MainActivity.this, "Good Morning", Toast.LENGTH_SHORT).show();
                }else if(timeOfDay >= 12 && timeOfDay < 16){ Toast.makeText(MainActivity.this, "Good Afternoon",
                        Toast.LENGTH_SHORT).show();
                }else if(timeOfDay >= 16 && timeOfDay < 21){ Toast.makeText(MainActivity.this, "Good Evening",
                        Toast.LENGTH_SHORT).show();
                }else if(timeOfDay >= 21 && timeOfDay < 24){ Toast.makeText(MainActivity.this, "Good Night",
                        Toast.LENGTH_SHORT).show();
                }
                Toast.makeText(MainActivity.this, "Hi", Toast.LENGTH_SHORT).show();
                String s=editText.getText().toString(); Float cgpa=Float.parseFloat(s);
                Double per=(7.1*cgpa)+11;
                textView.setText("Percentage is "+String.format("%.2f",per));
            }
        });
    }
}