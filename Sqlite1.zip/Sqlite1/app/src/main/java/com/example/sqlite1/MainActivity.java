package com.example.sqlite1;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private TextView t1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        t1=findViewById(R.id.textView);

        dhhandler dbh1=new dhhandler(this);
        SQLiteDatabase db1=dbh1.getReadableDatabase();

        Cursor cs1=db1.rawQuery("SELECT name,roll_no FROM STUDENTS",new String[]{});
        if(cs1!=null)
        {
            cs1.moveToFirst();
        }
        StringBuilder sb1=new StringBuilder();

        do {
            String name=cs1.getString(0);
            String roll=cs1.getString(1);
            sb1.append("Name: "+name+" Roll no: "+roll+"\n");
        }while(cs1.moveToNext());

        cs1.close();

        t1.setText(sb1.toString());
    }
}