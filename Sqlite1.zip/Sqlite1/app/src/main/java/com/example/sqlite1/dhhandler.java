package com.example.sqlite1;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class dhhandler extends SQLiteOpenHelper {

    private static final String dbname="mydb";
    private static final int version=1;

    public dhhandler(Context context) {
        super(context,dbname,null,version);
    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        String sql1="CREATE TABLE students(_id INTEGER PRIMARY KEY AUTOINCREMENT,name text,roll_no text)";
        db.execSQL(sql1);
        add_student("Aishwarya Jadhav","19",db);
        add_student("Tushar Vedpathak","60",db);
        add_student("Suraj Koli","50",db);
        add_student("Sayali Gurav","16",db);
        add_student("Sagar Pawar","49",db);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }
    public void add_student(String name,String roll_no,SQLiteDatabase db)
    {
        ContentValues values=new ContentValues();
        values.put("name",name);
        values.put("roll_no",roll_no);
        db.insert("students",null,values);

    }
}
